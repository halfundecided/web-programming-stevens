const peopleData = require('./people')
// const myinfoData = require('./myinfo')

module.exports = {
    people: peopleData,

}